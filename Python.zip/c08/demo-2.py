from selenium import webdriver
import requests
import datetime as dt
import time

headersvalue = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
}

# 输出文件名
output_file = "hot_bilibili_selenium.txt"

# 将时间戳转换为标准日期时间格式
def timestamp_to_timestr(timestamp):
    return dt.datetime.fromtimestamp(timestamp)

# 获取指定页面的视频数据
def get_video_data(url, pn, count, browser):
    # 向B站热门视频接口发送GET请求
    res = requests.get(url, headers=headersvalue, timeout=5)

    # 解析JSON数据，获取视频列表
    videos = res.json()["data"]["list"]

    # 打开文件，以追加方式写入数据
    with open(output_file, 'a', encoding='utf-8') as f:
        for v in videos:
            # 提取视频信息
            title = v['title']  # 视频标题
            owner = v['owner']['name']  # UP主名称
            view = v['stat']['view']  # 播放量
            link = v['short_link_v2']  # 视频链接
            desc = v['desc'].strip().replace(' ', '')  # 视频简介（去空格）
            pubdate = timestamp_to_timestr(v['pubdate'])  # 发布时间
            duration = v['duration']  # 视频时长（秒）

            # 输出视频标题
            print(f"{count}. {title}")

            # 将数据写入文件
            f.write(
                f"{count}. {title}\n发布日期: {pubdate}\n简介: {desc}\n时长: {duration}秒\nUP主: {owner}\n观看: {view}\n链接: {link}\n\n"
            )
            count += 1

    # 模拟浏览器滚动
    browser.execute_script("window.scrollTo(0, 280)")
    time.sleep(0.5)

    return count

# 主函数入口
def main():
    options = webdriver.ChromeOptions()
    options.add_argument(f"user-agent={headersvalue['User-Agent']}")

    with webdriver.Chrome(options=options) as browser:
        browser.get('https://www.bilibili.com/v/popular/all')
        time.sleep(1)

        count = 1  # 初始化视频计数器
        # 循环爬取第1到第2页的视频数据
        for pn in range(1, 3):
            url = f"https://api.bilibili.com/x/web-interface/popular?ps=20&pn={pn}"  # 构造API请求地址
            count = get_video_data(url, pn, count, browser)  # 获取并处理视频数据

            # 模拟翻页行为（滑到底部）
            browser.execute_script("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(1)  # 延迟加载下一页内容

# 主程序入口
if __name__ == '__main__':
    main()