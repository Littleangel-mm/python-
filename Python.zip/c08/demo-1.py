from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# 初始化Google Chrome浏览器
browser = webdriver.Chrome()
wait = WebDriverWait(browser, 10)  # WebDriverWait对象

# 访问网页
browser.get('https://shenzhen.qfang.com/')
time.sleep(1)

# 判断class属性为"navigation-wrap.clearfix"节点下的所有div节点是否加载完成
try:
    nav_elements = wait.until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, '.navigation-wrap.clearfix div'))
    )
    element = nav_elements[2]  # 选择第二个节点
    element.click()
except Exception as e:
    print("导航栏点击失败：", e)

time.sleep(1)
handles = browser.window_handles
browser.switch_to.window(handles[-1])
time.sleep(1)

for i in range(10):
    browser.execute_script("window.scrollTo(0, document.body.scrollHeight)")
    time.sleep(1)
    try:
        # 判断底部“下一页”节点是否加载完成
        next_page = wait.until(
            # By.CSS_SELECTOR是Selenium提供的一种定位方式，通过CSS选择器定位元素
            EC.presence_of_element_located((By.CSS_SELECTOR, '.page-turning-wrap.page-turning-center.fr.clearfix .btn-page-turning-next'))
        )
        # 获取第一个房源标题
        first_title = browser.find_element(By.CSS_SELECTOR, '.list-main-header.clearfix a').get_attribute('title')
        print(f"第{i+1}页第一个房源标题：{first_title}")
        next_page.click()
    except Exception as e:
        print("翻页失败：", e)
        break

browser.quit()