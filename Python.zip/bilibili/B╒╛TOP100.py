import time
import requests
import pandas as pd
from loguru import logger

# 分类
categorys = [{
    "name": "电影",
    "type": "cinema",
    "slug": "movie",
    "tid": 23,
    "season_type": 2
}]
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
}

def parse():
    for category in categorys:
        season_type = category.get("season_type")   # 类型
        name = category.get("name")     # 分类名
        logger.info(f"开始爬取：{name}")

        data = parse1(season_type)

        logger.info(f"数据获取成功：{data}")
        # 保存数据
        save_to_csv(data, f"B站TOP100-{name}.csv")
        logger.info(f"保存数据到csv文件：B站TOP100-{name}.csv")
        logger.info("------------------------------------")
    time.sleep(2)

def parse1(season_type):
    url = 'https://api.bilibili.com/pgc/season/rank/web/list'
    params = {
        'day': '3',
        'season_type': season_type,
    }
    resp = requests.get(url, params=params, headers=headers)
    result = resp.json()

    # 解析数据
    rank_list = result["data"]["list"]
    title_list = []
    url_list = []
    rating_list = []
    desc_list = []
    play_list = []
    view_list = []
    follow_list = []
    danmaku_list = []
    for rank in rank_list:
        title_list.append(rank.get("title"))  # 标题
        url_list.append(rank.get("url"))  # 链接
        rating_list.append(rank["rating"])  # 评分
        desc_list.append(rank["desc"])  # 更新至多少集
        play_list.append(rank["icon_font"]["text"])  # 播放数
        stat = rank["stat"]
        view_list.append(stat["view"])  # 播放数
        follow_list.append(stat["follow"])  # 关注数
        danmaku_list.append(stat["danmaku"])  # 弹幕数

    return {
        "标题": title_list,
        "链接": url_list,
        "评分": rating_list,
        "描述": desc_list,
        "播放数1": play_list,
        "播放数": view_list,
        "关注数": follow_list,
        "弹幕数": danmaku_list,
    }

def save_to_csv(data, csv_name):
    """
    数据保存到csv
    @param dms: 弹幕列表数据
    @param csv_name: csv文件名字
    @return:
    """
    # 把列表转换成 dataframe
    df = pd.DataFrame(data)
    # 写入数据
    df.to_csv(csv_name, index=False, encoding="utf_8_sig")

def get_season_comments():
    """获取番剧/电影的评论数"""
    url = f"https://api.bilibili.com/pgc/review/short/list"
    params = {
        "media_id": 48415,
        "ps": 1,
        "sort": "hot"
    }
    resp = requests.get(url, params=params, headers=headers)
    if resp.status_code == 200:
        data = resp.json()
        return data["data"]["total"]  # 返回评论总数
    return 0

if __name__ == '__main__':
    get_season_comments()
    # parse()






