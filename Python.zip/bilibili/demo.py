import time
from typing import Dict, List, Any
import requests
import pandas as pd
from loguru import logger
from bs4 import BeautifulSoup
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache

@dataclass
class Category:
    name: str
    type: str
    slug: str
    tid: int
    season_type: int

# 分类
categories = [
    Category(
        name="电影",
        type="cinema",
        slug="movie",
        tid=23,
        season_type=2
    )
]

headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
    'referer': 'https://www.bilibili.com'
}

@lru_cache(maxsize=128)
def get_api_data(season_type: int) -> Dict[str, Any]:
    url = 'https://api.bilibili.com/pgc/season/rank/web/list'
    params = {
        'day': '3',
        'season_type': season_type,
    }
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        logger.error(f"API request failed: {str(e)}")
        return {"data": {"list": []}}

def parse1(season_type: int) -> Dict[str, List[Any]]:
    result = get_api_data(season_type)

    if not result.get("data", {}).get("list"):
        logger.error("No data received from API")
        return {
            "标题": [], "链接": [], "评分": [],
            "播放数（万）": [], "播放数": [], "弹幕数": []
        }

    rank_list = result["data"]["list"]
    return {
        "标题": [rank.get("title", "") for rank in rank_list],
        "链接": [rank.get("url", "") for rank in rank_list],
        "评分": [rank.get("rating", "0") for rank in rank_list],
        "播放数（万）": [rank.get("icon_font", {}).get("text", "0") for rank in rank_list],
        "播放数": [rank.get("stat", {}).get("view", 0) for rank in rank_list],
        "弹幕数": [rank.get("stat", {}).get("danmaku", 0) for rank in rank_list]
    }

def get_video_details(url: str) -> Dict[str, Any]:
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'html.parser')

        info_wrap = soup.find('div', class_='mediainfo_mediaInfoWrap__nCwhA')
        if not info_wrap:
            return create_empty_video_data()

        # Extract all required information
        return {
            "主演": extract_actors(info_wrap),
            "上映时间": extract_pubdate(info_wrap),
            "弹幕数": extract_danmaku(info_wrap),
            "封面链接": extract_cover(url),
            "评分": extract_rank(info_wrap),
            "视频简介": extract_intro(info_wrap),
            "标签": extract_tags(info_wrap),
            "追剧数": extract_follows(info_wrap)
        }
    except Exception as e:
        logger.error(f"Error processing video {url}: {str(e)}")
        return create_empty_video_data()

def create_empty_video_data() -> Dict[str, Any]:
    """Create empty video data structure"""
    return {
        "主演": "暂无",
        "上映时间": "暂无",
        "弹幕数": "0",
        "封面链接": "",
        "评分": "0",
        "视频简介": "暂无",
        "标签": "暂无",
        "追剧数": "0"
    }

def extract_actors(info_wrap: BeautifulSoup) -> str:
    """Extract actors information"""
    actors = []
    actors_div = info_wrap.find('div', class_='mediainfo_mediaDesc__jjRiB', title=True)
    if actors_div:
        actors_text = actors_div.get('title', '')
        if actors_text:
            actors = [actor.strip() for actor in actors_text.split()]
    return "、".join(actors) if actors else "暂无"

def extract_pubdate(info_wrap: BeautifulSoup) -> str:
    """Extract publication date"""
    desc_divs = info_wrap.find_all('div', class_='mediainfo_mediaDesc__jjRiB')
    for desc in desc_divs:
        text = desc.text.strip()
        if '上映' in text:
            date_part = text.split('上映')[0].strip()
            if '·' in date_part:
                date_part = date_part.split('·')[1].strip()
            return date_part
    return "暂无"


def extract_danmaku(info_wrap: BeautifulSoup) -> str:
    """Extract danmaku count"""
    stats_div = info_wrap.find('div', class_='mediainfo_mediaDesc__jjRiB')
    if stats_div:
        stats_text = stats_div.text.strip()
        stats = stats_text.split('·')
        if len(stats) >= 3:
            return stats[1].strip().replace('万弹幕', '')
    return "0"

def extract_cover(url: str) -> str:
    """Extract cover image URL"""
    try:
        season_id = int(url.split('ss')[1].split('?')[0])
        result = get_api_data(2)  # Using cached API data
        for rank in result.get("data", {}).get("list", []):
            if rank.get("season_id") == season_id:
                return rank.get("cover", "")
        return ""
    except Exception as e:
        logger.error(f"Error extracting cover: {str(e)}")
        return ""

def extract_rank(info_wrap: BeautifulSoup) -> str:
    """Extract video rank"""
    score_div = info_wrap.find('div', class_='mediainfo_score__SQ_KG')
    if score_div:
        return score_div.text.strip().replace('分', '')
    return "0"

def extract_intro(info_wrap: BeautifulSoup) -> str:
    """Extract video introduction"""
    intro = info_wrap.find('p', class_='mediainfo_content__rexOq')
    return intro.text.strip() if intro else "暂无"

def extract_tags(info_wrap: BeautifulSoup) -> str:
    """Extract video tags"""
    desc_divs = info_wrap.find_all('div', class_='mediainfo_mediaDesc__jjRiB')
    styles = []
    for desc in desc_divs:
        text = desc.text.strip()
        if '/' in text and '·' in text:
            tags = text.split('·')[0].strip()
            styles.extend([tag.strip() for tag in tags.split('/')])

    # Filter out date-related tags
    styles = [tag for tag in styles if '年' not in tag and '月' not in tag and '日' not in tag]
    return "、".join(styles) if styles else "暂无"

def extract_follows(info_wrap: BeautifulSoup) -> str:
    """Extract follow count"""
    stats_div = info_wrap.find('div', class_='mediainfo_mediaDesc__jjRiB')
    if stats_div:
        stats_text = stats_div.text.strip()
        stats = stats_text.split('·')
        if len(stats) >= 3:
            return stats[2].strip().replace('万追剧', '')
    return "0"

def parse() -> None:
    """Main parsing function with parallel processing"""
    for category in categories:
        logger.info(f"开始爬取：{category.name}")

        # Get initial data
        data = parse1(category.season_type)

        # Limit to first 3 videos
        for key in data:
            data[key] = data[key][:3]

        # Process videos in parallel
        with ThreadPoolExecutor(max_workers=3) as executor:
            detailed_data_list = list(executor.map(get_video_details, data["链接"]))

        # Merge detailed data
        detailed_data = {
            key: [item[key] for item in detailed_data_list]
            for key in detailed_data_list[0].keys()
        }

        # Merge all data
        merged_data = {**data, **detailed_data}

        logger.info(f"数据获取成功，共{len(merged_data['标题'])}条记录")
        save_to_csv(merged_data, f"demo-{category.name}-完整版.csv")
        logger.info(f"保存数据到csv文件：demo-{category.name}-完整版.csv")
        logger.info("------------------------------------")
        time.sleep(2)

def save_to_csv(data: Dict[str, List[Any]], csv_name: str) -> None:
    """Save data to CSV file"""
    try:
        df = pd.DataFrame(data)
        df.to_csv(csv_name, index=False, encoding="utf_8_sig")
    except Exception as e:
        logger.error(f"Error saving to CSV {csv_name}: {str(e)}")

if __name__ == '__main__':
    parse()

