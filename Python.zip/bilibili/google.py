import time
import pandas as pd 
from loguru import logger
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import json
import requests as req

# 分类
categorys = [{
    "name": "电影",
    "type": "cinema",
    "slug": "movie",
    "tid": 23,
    "season_type": 2
}]

def setup_driver():
    """设置Chrome WebDriver"""
    chrome_options = Options()
    # chrome_options.add_argument('--headless')  # 注释掉无头模式
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--window-size=1920,1080')
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36')
    
    # 使用 webdriver_manager 自动管理 ChromeDriver
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

def parse():
    driver = setup_driver()
    try:
        for category in categorys:
            season_type = category.get("season_type")   # 类型
            name = category.get("name")     # 分类名
            logger.info(f"开始爬取：{name}")

            data = parse1(driver, season_type)
            
            # 只取前三个视频的链接
            data["链接"] = data["链接"][:3]
            data["标题"] = data["标题"][:3]
            data["评分"] = data["评分"][:3]
            data["描述"] = data["描述"][:3]
            data["播放数1"] = data["播放数1"][:3]
            data["播放数"] = data["播放数"][:3]
            data["关注数"] = data["关注数"][:3]
            data["弹幕数"] = data["弹幕数"][:3]

            # 获取每个链接的详细信息
            detailed_data = get_video_details(driver, data["链接"])
            
            # 合并数据
            merged_data = {**data, **detailed_data}
            
            logger.info(f"数据获取成功，共{len(merged_data['标题'])}条记录")
            # 保存数据
            save_to_csv(merged_data, f"demo-{name}-完整版.csv")
            logger.info(f"保存数据到csv文件：demo-{name}-完整版.csv")
            logger.info("------------------------------------")
            time.sleep(2)
    finally:
        driver.quit()

def parse1(driver, season_type):
    url = 'https://api.bilibili.com/pgc/season/rank/web/list'
    params = {
        'day': '3',
        'season_type': season_type,
    }
    
    # 启用 CDP 性能日志
    driver.execute_cdp_cmd('Network.enable', {})
    
    # 访问 API
    driver.get(f"{url}?day=3&season_type={season_type}")
    
    # 等待页面加载完成
    time.sleep(2)
    
    # 获取所有网络请求
    requests = driver.execute_cdp_cmd('Network.getAllCookies', {})
    
    # 直接使用 requests 库获取数据
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
        'referer': 'https://www.bilibili.com'
    }
    response = req.get(f"{url}?day=3&season_type={season_type}", headers=headers)
    result = response.json()
    
    if 'data' not in result or 'list' not in result['data']:
        logger.error("未获取到数据")
        return {
            "标题": [],
            "链接": [],
            "评分": [],
            "描述": [],
            "播放数1": [],
            "播放数": [],
            "关注数": [],
            "弹幕数": [],
        }
    
    rank_list = result['data']['list']
    title_list = []
    url_list = []
    rating_list = []
    desc_list = []
    play_list = []
    view_list = []
    follow_list = []
    danmaku_list = []
    
    for rank in rank_list:
        title_list.append(rank.get("title"))  # 标题
        url_list.append(rank.get("url"))  # 链接
        rating_list.append(rank["rating"])  # 评分
        desc_list.append(rank["desc"])  # 更新至多少集
        play_list.append(rank["icon_font"]["text"])  # 播放数
        stat = rank["stat"]
        view_list.append(stat["view"])  # 播放数
        follow_list.append(stat["follow"])  # 关注数
        danmaku_list.append(stat["danmaku"])  # 弹幕数

    return {
        "标题": title_list,
        "链接": url_list,
        "评分": rating_list,
        "描述": desc_list,
        "播放数1": play_list,
        "播放数": view_list,
        "关注数": follow_list,
        "弹幕数": danmaku_list,
    }

def get_video_details(driver, url_list):
    """获取每个视频链接的详细信息"""
    actors_list = []
    pubdate_list = []
    like_list = []
    share_list = []
    cover_list = []
    rank_list = []
    intro_list = []
    style_list = []
    reply_list = []
    
    for url in url_list:
        try:
            driver.get(url)
            # 等待页面加载
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, "mediainfo_mediaInfoWrap__nCwhA"))
            )
            
            # 获取详细信息区域
            info_wrap = driver.find_element(By.CLASS_NAME, "mediainfo_mediaInfoWrap__nCwhA")
            if not info_wrap:
                logger.warning(f"未找到详细信息区域: {url}")
                actors_list.append("暂无")
                pubdate_list.append("暂无")
                like_list.append("0")
                share_list.append("0")
                reply_list.append("0")
                cover_list.append("")
                rank_list.append("0")
                intro_list.append("暂无")
                style_list.append("暂无")
                continue
                
            # 获取视频标题
            try:
                title = info_wrap.find_element(By.CLASS_NAME, "mediainfo_mediaTitle__Zyiqh")
                if title:
                    logger.info(f"正在获取视频: {title.text.strip()}")
            except:
                pass
            
            # 获取视频简介
            try:
                intro = info_wrap.find_element(By.CLASS_NAME, "mediainfo_content__rexOq")
                intro_list.append(intro.text.strip() if intro else "暂无")
            except:
                intro_list.append("暂无")
            
            # 获取标签和上映时间
            styles = []
            pubdate = ""
            try:
                desc_divs = info_wrap.find_elements(By.CLASS_NAME, "mediainfo_mediaDesc__jjRiB")
                for desc in desc_divs:
                    text = desc.text.strip()
                    if '上映' in text:
                        # 提取上映时间，只保留日期部分
                        date_part = text.split('上映')[0].strip()
                        if '·' in date_part:
                            date_part = date_part.split('·')[1].strip()
                        pubdate = date_part
                        # 提取标签
                        if '·' in text:
                            tags = text.split('·')[0].strip()
                            styles.extend([tag.strip() for tag in tags.split('/')])
                    elif '/' in text and '·' in text:
                        # 提取标签
                        tags = text.split('·')[0].strip()
                        styles.extend([tag.strip() for tag in tags.split('/')])
            except:
                pass
            
            # 确保标签不包含上映时间
            styles = [tag for tag in styles if '年' not in tag and '月' not in tag and '日' not in tag]
            style_list.append("、".join(styles) if styles else "暂无")
            pubdate_list.append(pubdate if pubdate else "暂无")
            
            # 获取演员信息
            actors = []
            try:
                actors_div = info_wrap.find_element(By.CLASS_NAME, "mediainfo_mediaDesc__jjRiB")
                if actors_div:
                    actors_text = actors_div.get_attribute('title')
                    if actors_text:
                        actors = [actor.strip() for actor in actors_text.split()]
            except:
                pass
            actors_list.append("、".join(actors) if actors else "暂无")
            
            # 获取评分
            try:
                score_div = info_wrap.find_element(By.CLASS_NAME, "mediainfo_score__SQ_KG")
                if score_div:
                    score = score_div.text.strip().replace('分', '')
                    rank_list.append(score)
                else:
                    rank_list.append("0")
            except:
                rank_list.append("0")
            
            # 获取播放数据
            try:
                stats_div = info_wrap.find_element(By.CLASS_NAME, "mediainfo_mediaDesc__jjRiB")
                if stats_div:
                    stats_text = stats_div.text.strip()
                    # 提取播放数、弹幕数、追剧数
                    stats = stats_text.split('·')
                    if len(stats) >= 3:
                        play_count = stats[0].strip().replace('万播放', '')
                        danmaku_count = stats[1].strip().replace('万弹幕', '')
                        follow_count = stats[2].strip().replace('万追剧', '')
                        like_list.append(play_count)
                        share_list.append(danmaku_count)
                        reply_list.append(follow_count)
                    else:
                        like_list.append("0")
                        share_list.append("0")
                        reply_list.append("0")
                else:
                    like_list.append("0")
                    share_list.append("0")
                    reply_list.append("0")
            except:
                like_list.append("0")
                share_list.append("0")
                reply_list.append("0")
            
            # 获取转发数
            try:
                demo = driver.find_element(By.CLASS_NAME, "toolbar-left")
                if demo:
                    share_span = demo.find_element(By.CLASS_NAME, "share")
                    if share_span:
                        flow_text = share_span.find_element(By.CLASS_NAME, "flow-text")
                        if flow_text:
                            share_count = flow_text.text.strip()
            except:
                share_count = "0"
            
            # 获取封面
            try:
                # 从URL中提取season_id
                season_id = int(url.split('ss')[1].split('?')[0])
                driver.get('https://api.bilibili.com/pgc/season/rank/web/list?day=3&season_type=2')
                result = driver.execute_script("return window.performance.getEntries()[0].response")
                # 解析数据
                list = result["data"]["list"]
                for rank in list:
                    id = rank.get("season_id")
                    if id == season_id:
                        cover = rank.get("cover")
                        cover_list.append(cover)
                        break
            except:
                cover_list.append("")
            
            # 避免请求过快被封
            time.sleep(0.5)
            
        except Exception as e:
            logger.error(f"处理视频详情时出错: {url} - {str(e)}")
            # 添加空数据以保持长度一致
            actors_list.append("暂无")
            pubdate_list.append("暂无")
            like_list.append("0")
            share_list.append("0")
            reply_list.append("0")
            cover_list.append("")
            rank_list.append("0")
            intro_list.append("暂无")
            style_list.append("暂无")
            continue
    
    return {
        "主演": actors_list,
        "上映时间": pubdate_list,
        "点赞数": like_list,
        "转发数": share_count,
        "弹幕数": share_list,
        "封面链接": cover_list,
        "排名": rank_list,
        "视频简介": intro_list,
        "标签": style_list,
        "追剧数": reply_list
    }

def save_to_csv(data, csv_name):
    """数据保存到csv"""
    df = pd.DataFrame(data)
    df.to_csv(csv_name, index=False, encoding="utf_8_sig")

if __name__ == '__main__':
    parse()
