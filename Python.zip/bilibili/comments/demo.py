import time
import requests
import pandas as pd
from loguru import logger
from bs4 import BeautifulSoup

# 分类
categorys = [{
    "name": "电影",
    "type": "cinema",
    "slug": "movie",
    "tid": 23,
    "season_type": 2
}]
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
    'referer': 'https://www.bilibili.com'
}


def parse():
    for category in categorys:
        season_type = category.get("season_type")  # 类型
        name = category.get("name")  # 分类名
        logger.info(f"开始爬取：{name}")

        data = parse1(season_type)

        # 只取前三个视频的链接
        # data["链接"] = data["链接"][:3]
        # data["标题"] = data["标题"][:3]
        # data["评分"] = data["评分"][:3]
        # data["播放数"] = data["播放数"][:3]
        # data["关注数"] = data["关注数"][:3]
        # data["弹幕数"] = data["弹幕数"][:3]

        # 获取每个链接的详细信息
        detailed_data = get_video_details(data["链接"])

        # 合并数据
        merged_data = {**data, **detailed_data}

        logger.info(f"数据获取成功，共{len(merged_data['标题'])}条记录")
        # 保存数据
        save_to_csv(merged_data, f"B站TOP100-{name}.csv")
        logger.info(f"保存数据到csv文件：B站TOP100-{name}.csv")
        logger.info("------------------------------------")
    time.sleep(2)


def parse1(season_type):
    url = 'https://api.bilibili.com/pgc/season/rank/web/list'
    params = {
        'day': '3',
        'season_type': season_type,
    }
    resp = requests.get(url, params=params, headers=headers)
    result = resp.json()

    # 解析数据
    rank_list = result["data"]["list"]
    title_list = []
    url_list = []
    rating_list = []
    desc_list = []
    play_list = []
    view_list = []
    follow_list = []
    for rank in rank_list:
        title_list.append(rank.get("title"))
        url_list.append(rank.get("url"))
        rating_list.append(rank["rating"])
        desc_list.append(rank["desc"])
        play_list.append(rank["icon_font"]["text"])
        stat = rank["stat"]
        view_list.append(stat["view"])
        follow_list.append(stat["follow"])

    return {
        "标题": title_list,
        "链接": url_list,
        "评分": rating_list,
        "弹幕数": desc_list,
        "播放数": play_list,
        # "播放数": view_list,
        "关注数": follow_list,
    }


def get_video_details(url_list):
    """获取每个视频链接的详细信息"""
    actors_list = []
    pubdate_list = []
    like_list = []
    share_list = []
    cover_list = []
    rank_list = []
    intro_list = []
    style_list = []
    reply_list = []

    for url in url_list:
        try:
            resp = requests.get(url, headers=headers)
            if resp.status_code != 200:
                logger.error(f"请求失败: {resp.status_code} - {url}")
                actors_list.append("暂无")
                pubdate_list.append("暂无")
                like_list.append("0")
                share_list.append("0")
                cover_list.append("")
                rank_list.append("0")
                intro_list.append("暂无")
                style_list.append("暂无")
                reply_list.append("0")
                continue

            soup = BeautifulSoup(resp.text, 'html.parser')

            # # 获取详细信息区域
            info_wrap = soup.find('div', class_='mediainfo_mediaInfoWrap__nCwhA')
            # demo = soup.find('div', class_='toolbar-left')
            # share_count = "0"
            # if demo:
            #     share_span = demo.find('span', class_='share')
            #     if share_span:
            #         flow_text = share_span.find('div', class_='flow-text')
            #         if flow_text:
            #             share_count = flow_text.text.strip()



            if not info_wrap:
                logger.warning(f"未找到详细信息区域: {url}")
                actors_list.append("暂无")
                pubdate_list.append("暂无")
                like_list.append("0")
                share_list.append("0")
                reply_list.append("0")
                cover_list.append("")
                rank_list.append("0")
                intro_list.append("暂无")
                style_list.append("暂无")
                continue

            # 获取视频标题
            title = info_wrap.find('a', class_='mediainfo_mediaTitle__Zyiqh')
            if title:
                logger.info(f"正在获取视频: {title.text.strip()}")

            # 获取视频简介
            intro = info_wrap.find('p', class_='mediainfo_content__rexOq')
            intro_list.append(intro.text.strip() if intro else "暂无")

            # 获取标签和上映时间
            desc_divs = info_wrap.find_all('div', class_='mediainfo_mediaDesc__jjRiB')
            styles = []
            pubdate = ""

            for desc in desc_divs:
                text = desc.text.strip()
                if '上映' in text:
                    # 提取上映时间，只保留日期部分
                    date_part = text.split('上映')[0].strip()
                    if '·' in date_part:
                        date_part = date_part.split('·')[1].strip()
                    pubdate = date_part
                    # 提取标签
                    if '·' in text:
                        tags = text.split('·')[0].strip()
                        styles.extend([tag.strip() for tag in tags.split('/')])
                elif '/' in text and '·' in text:
                    # 提取标签
                    tags = text.split('·')[0].strip()
                    styles.extend([tag.strip() for tag in tags.split('/')])

            # 确保标签不包含上映时间
            styles = [tag for tag in styles if '年' not in tag and '月' not in tag and '日' not in tag]
            style_list.append("、".join(styles) if styles else "暂无")
            pubdate_list.append(pubdate if pubdate else "暂无")

            # 获取演员信息
            actors = []
            actors_div = info_wrap.find('div', class_='mediainfo_mediaDesc__jjRiB', title=True)
            if actors_div:
                actors_text = actors_div.get('title', '')
                if actors_text:
                    actors = [actor.strip() for actor in actors_text.split()]
            actors_list.append("、".join(actors) if actors else "暂无")

            # 获取评分
            score_div = info_wrap.find('div', class_='mediainfo_score__SQ_KG')
            if score_div:
                score = score_div.text.strip().replace('分', '')
                rank_list.append(score)
            else:
                rank_list.append("0")

            # 获取播放数据
            stats_div = info_wrap.find('div', class_='mediainfo_mediaDesc__jjRiB')
            if stats_div:
                stats_text = stats_div.text.strip()
                # 提取播放数、弹幕数、追剧数
                stats = stats_text.split('·')
                if len(stats) >= 3:
                    play_count = stats[0].strip().replace('万播放', '')
                    danmaku_count = stats[1].strip().replace('万弹幕', '')
                    follow_count = stats[2].strip().replace('万追剧', '')
                    like_list.append(play_count)
                    share_list.append(danmaku_count)
                    reply_list.append(follow_count)
                else:
                    like_list.append("0")
                    share_list.append("0")
                    reply_list.append("0")
            else:
                like_list.append("0")
                share_list.append("0")
                reply_list.append("0")

            # 封面
            # 从URL中提取season_id
            season_id = int(url.split('ss')[1].split('?')[0])
            url = 'https://api.bilibili.com/pgc/season/rank/web/list'
            params = {
                'day': '3',
                'season_type': 2,
            }
            resp = requests.get(url, params=params, headers=headers)
            result = resp.json()
            # 解析数据
            list = result["data"]["list"]
            for rank in list:
                id = rank.get("season_id")
                if id == season_id:
                    # print(rank)
                    cover = rank.get("cover")
                    cover_list.append(cover)

            # 避免请求过快被封
            time.sleep(0.5)

        except Exception as e:
            logger.error(f"处理视频详情时出错: {url} - {str(e)}")
            # 添加空数据以保持长度一致
            actors_list.append("暂无")
            pubdate_list.append("暂无")
            like_list.append("0")
            share_list.append("0")
            cover_list.append("")
            rank_list.append("0")
            intro_list.append("暂无")
            style_list.append("暂无")
            reply_list.append("0")
            continue

    return {
        "主演": actors_list,
        "上映时间": pubdate_list,
        "弹幕数": share_list,
        "封面链接": cover_list,
        "排名": rank_list,
        "视频简介": intro_list,
        "标签": style_list,
        "追剧数": reply_list
    }


def save_to_csv(data, csv_name):
    df = pd.DataFrame(data)
    df.to_csv(csv_name, index=False, encoding="utf_8_sig")


if __name__ == '__main__':
    parse()