import requests  # 导入requests库，用于发送HTTP请求
import chardet   # 导入chardet库，用于检测网页的字符编码

# 定义豆瓣电影Top250的URL
base_url = 'https://movie.douban.com/top250'

# 设置HTTP请求头，伪装成浏览器访问，防止被网站屏蔽
headersvalue = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36'
}

# 通过循环翻页，爬取Top250的多个页面（每页显示25部电影，共10页）
for i in range(0, 10):
    # 设置URL参数，'star'代表起始电影序号，每次增加25以翻页
    paramsvalue = {'start': str(i * 25), 'filter': ''}

    # 使用异常处理，防止网络请求超时导致程序崩溃
    try:
        # 发送GET请求，获取网页内容，并将返回结果赋值给r
        r = requests.get(base_url, params=paramsvalue, headers=headersvalue, timeout=1)

        # 如果请求超时，捕获异常并打印超时信息
    except requests.Timeout:
        print('Timeout!')
    else:
        # 如果请求成功，则执行以下操作
        if r.status_code == 200:
            # 打印HTTP响应状态码（200表示成功）
            print(r.status_code)
            # 打印最终请求的URL（包含参数）
            print(r.url)

            # 使用chardet自动检测网页的编码格式
            code_type = chardet.detect(r.content)['encoding']

            # 以UTF-8编码方式打开（或创建）文件movie.txt，并将爬取的网页内容写入文件
            with open('movie.txt', 'a+', encoding='utf-8') as f:
                f.write(r.content.decode(code_type))
        else:
            print(f"Failed to retrieve page: {r.status_code}")