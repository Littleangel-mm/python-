import requests
import math
from bs4 import BeautifulSoup
import csv
import time
import re

base_url = 'https://shenzhen.qfang.com/rent'
headersvalue = {
    'Cookie': 'language=SIMPLIFIED; _ga=GA1.1.2132135325.1741912227; CITY_NAME=SHENZHEN; qchatid=5bc3c349-92da-4df4-ba40-75abfe85ac38; cookieId=e97b62d2-1c78-4165-a761-05871124a1a7; WINDOW_DEVICE_PIXEL_RATIO=2; SALEROOMREADRECORDCOOKIE=504932429%23504931789; looks=SALE%2C504932429%2C57312%7CSALE%2C504931789%2C57468; Hm_lvt_561b8479f4e1e98419908032a2629883=1741912240,1741912883,1742948819; HMACCOUNT=1A08CE4E89B6B69D; sid=81308ef5-f5a1-4b6b-8450-36430da9297a; JSESSIONID=aaaD3nFEFyu-O87xN5_vz; Hm_lpvt_561b8479f4e1e98419908032a2629883=1742949420; _ga_GV01F4QGNH=GS1.1.1742948840.2.1.1742949555.0.0.0',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
}


def get_allpage_info():
    r = requests.get(base_url, headers=headersvalue)
    soup = BeautifulSoup(r.text, 'lxml')
    total_house = soup.select('.list-total span')[0].text.strip()  # 获取总房源数
    total_page = math.ceil(int(total_house) / 30)  # 获取房源总页数
    for i in range(1, total_page + 1):
        url = base_url + '/f' + str(i)
        # 调用get_onepage_info函数
        get_onepage_info(url)
        time.sleep(1)


# 获取单页面房源信息
def get_onepage_info(url):
    r = requests.get(url, headers=headersvalue)
    soup = BeautifulSoup(r.text, 'lxml')
    houses = soup.select('.list-result li')  # 获取所有房源信息
    for house in houses:
        info_list = []
        # 获取包含房屋信息的p节点，并赋值给house_metas
        house_metas = house.select('.house-metas.clearfix p')
        for item in house_metas:
            if item.text == None:
                # 如果为空，将None添加到info_list中
                info_list.append('None')
            else:
                # 如果不为空，将节点文本信息添加到info_list中
                info_list.append(item.text.strip())
        # 获取包含租金的span节点，并赋值给list_price
        list_price = house.select('.list-price span')
        # 组合span节点文本，并赋值给price
        price = list_price[0].text + list_price[1].text
        info_list.append(price)  # 将price添加到info_list中
        # 获取小区信息，并赋值给location
        location = house.select('.house-location.clearfix div')[0].text.strip()
        location_one_line = re.sub(r'\s+', ' ', location)
        # 将location添加到info_list中
        info_list.append(location_one_line)
        # 调用save_csvfile函数
        save_csvfile(info_list)


# 保存到CSV文件中
def save_csvfile(list):
    with open('house_info.csv', 'a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(list)


if __name__ == '__main__':
    get_allpage_info()
