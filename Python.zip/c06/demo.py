# P85
import requests
from bs4 import BeautifulSoup

url = 'https://shenzhen.qfang.com/rent'

r = requests.get(url)

soup = BeautifulSoup(r.text, 'lxml')

result = soup.find('div', class_='list-result')
print(result)
title = result.a.string.strip()


print(title)