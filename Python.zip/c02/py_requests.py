import requests

response = requests.get('https://doudao.com/')

print("响应类型", type(requests))
print("请求URL", response.url)
print("响应状态码", response.status_code)
print("请求头", response.request.headers)
print("响应头", response.headers)