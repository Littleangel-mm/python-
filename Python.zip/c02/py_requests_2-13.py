import requests
import base64

response = requests.get('https://img9.doubanio.com/view/subject/s/public/s33643895.jpg')
                        
# print(response.content)
# print(response.text)

print(base64.b64encode(response.content).decode('utf-8'))  # 将二进制数据转换为 Base64 字符串

with open('s33643895.jpg', 'wb') as f:
    f.write(response.content)