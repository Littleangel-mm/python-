import urllib.request

url = 'https://fanyi.youdao.com/'

response = urllib.request.urlopen(url)


print('响应状态码：', type(response))
print('响应状态码：', response.status)
print('响应头：', response.getheaders())
print('响应体：', response.read().decode('utf-8'))
print('编码方式', response.headers.get('Content-Type'))

resp = response.read().decode('utf-8')
print(resp)