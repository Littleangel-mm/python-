import chardet
import requests
import urllib.parse
from lxml import etree

# 定义小说的基本信息
novel_base_url = 'https://www.biqudu.com'
novel_url = urllib.parse.urljoin(novel_base_url, '/50_50096/')
chapter_url_list = []
headersvalue = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
}

# 获取小说每个章节的链接
def fetch_chapter_urls():
    r = requests.get(novel_url, headers=headersvalue)
    html = etree.HTML(r.text)
    hrefs = html.xpath('//dd/a/@href') # a标签的href属性
    for href in hrefs:
        if href not in chapter_url_list:
            # 将合法的url链接赋值给chapter_url
            chapter_url = urllib.parse.urljoin(novel_base_url, href)
            # 将chapter_url加入chapter_url_list列表中
            chapter_url_list.append(chapter_url)
    chapter_url_list.sort()  # 对chapter_url_list列表进行排序

# 获取每个章节的标题和正文
def parse_chapter(url):
    # 设置headers，发送请求，并将返回结果赋值给r
    r = requests.get(url, headers=headersvalue)
    # 检测返回内容编码类型
    code_type = chardet.detect(r.content)['encoding']
    if code_type == 'GB2312':
        code_type = 'GBK'
    r.encoding = code_type  # 重新定义返回内容编码类型
    html = etree.HTML(r.text)  # 创建HTML对象
    title = html.xpath('//h1/text()')[0]  # 小说章节标题
    contents = html.xpath('//div[@id="content"]/text()')  # 小说章节内容
    content = ''
    for i in contents:
        content += i.strip()  # 移除字符串头尾的空格或换行符，与content相加并赋值给content

    save_novel(title, content)  # 调用save_novel()函数

# 保存文件
def save_novel(title, content):
    try:
        with open(title + '.txt', 'w', encoding='utf-8') as f:
            f.write(content.strip())  
    except urllib.error.HTTPError as e:
        print(e.reason)
    else:
        print('下载完成：' + title)

if __name__ == '__main__':
    fetch_chapter_urls()
    print(chapter_url_list)
    for chapter in chapter_url_list:
        parse_chapter(chapter)