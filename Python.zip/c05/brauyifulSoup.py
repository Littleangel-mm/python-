import requests
from bs4 import BeautifulSoup

url = 'https://shenzhen.qfang.com/'

r = requests.get(url)

soup = BeautifulSoup(r.text, 'lxml')

title = soup.find(
    'div', class_='house-name'
    ).a.string.strip()

print(title)