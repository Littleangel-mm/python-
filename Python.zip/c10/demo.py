import time
import random
import requests
from urllib.parse import urlencode
from bs4 import BeautifulSoup
import csv

# 定义base_url字符串
base_url = 'https://search.bilibili.com/all?'
headersvalue = {
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'referer': 'https://www.bilibili.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8'
}

# 定义解析内容函数
def parse_content(content):
    items = []  # 定义items列表
    soup = BeautifulSoup(content, 'lxml')  # 创建BeautifulSoup对象，并设置使用lxml解析器
    video_list = soup.select('.bili-video-card')  # 更新选择器
    
    if not video_list:
        print("警告：未找到视频列表，可能是页面结构已更改或请求被限制")
        return items
        
    for video in video_list:
        try:
            title_elem = video.select_one('.bili-video-card__info--title')
            title = title_elem.text.strip() if title_elem else "未知标题"
            
            time_elem = video.select_one('.bili-video-card__info--duration')
            video_time = time_elem.text.strip() if time_elem else "未知时长"
            
            view_elem = video.select_one('.bili-video-card__stats--item span')
            view_count = view_elem.text.strip() if view_elem else "未知观看次数"
            
            up_time_elem = video.select_one('.bili-video-card__info--owner span:nth-child(2)')
            up_time = up_time_elem.text.strip() if up_time_elem else "未知上传时间"
            
            up_master_elem = video.select_one('.bili-video-card__info--author')
            up_master = up_master_elem.text.strip() if up_master_elem else "未知UP主"
            
            link_elem = video.select_one('.bili-video-card__info--right a')
            video_link = "https:" + link_elem['href'] if link_elem and 'href' in link_elem.attrs else "未知链接"
            
            item = {
                '视频标题': title,
                '视频时长': video_time,
                '观看次数': view_count,
                '上传时间': up_time,
                'up主': up_master,
                '视频链接': video_link
            }
            items.append(item)
        except Exception as e:
            print(f"解析视频信息时出错: {str(e)}")
            continue
            
    return items

# 定义获取每一页信息的函数
def get_one_page(kw, page):
    params = {
        'keyword': kw,
        'page': str(page)
    }
    url = base_url + urlencode(params)  # 合并URL
    try:
        r = requests.get(url, headers=headersvalue, timeout=10)
        r.raise_for_status()  # 检查响应状态
    except requests.exceptions.RequestException as e:
        print(f'请求失败: {str(e)}')
        return []
    else:
        if r.status_code == 200:
            items = parse_content(r.text)  # 调用parse_content函数
            sleep_time = random.uniform(2, 5)  # 设置随机休眠时间
            time.sleep(sleep_time)  # 程序休眠sleep_time
            return items
        else:
            print(f'请求错误，状态码: {r.status_code}')
            return []

if __name__ == '__main__':
    keyword = input('请输入搜索关键字：')  # 输入搜索关键字
    with open(keyword + '.csv', 'w', newline='', encoding='utf-8') as file:  # 打开data.csv文件写入数据
        names = ['视频标题', '视频时长', '观看次数', '上传时间', 'up主', '视频链接']  # 定义表头
        writer = csv.DictWriter(file, fieldnames=names)
        writer.writeheader()  # 写入表头
        for i in range(1, 51):  # 输出正在爬取第%d页的视频信息 % i
            print(f'正在获取第{i}页的视频信息')
            items = get_one_page(keyword, i)  # 调用get_one_page函数
            if items:
                writer.writerows(items)  # 写入items
            else:
                print(f'第{i}页获取失败，跳过')