from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
from selenium.common.exceptions import TimeoutException
import pymongo
import time

# 初始化Google Chrome浏览器对象
browser = webdriver.Chrome()
wait = WebDriverWait(browser, 10)  # 初始化WebDriverWait对象

# 创建MongoClient类对象
client = pymongo.MongoClient('localhost', 27017)
mongo = client.cnki  # 选择数据库，如果不存在则新建一个数据库
collection = mongo.papers  # 选择集合，如果不存在则新建一个集合

def searcher(keyword):
    browser.get('https://www.cnki.net/')
    browser.maximize_window()
    time.sleep(2)

    # 通过id属性定位“搜索”输入框节点，并赋值给input
    input = wait.until(
        EC.presence_of_element_located((By.ID, 'txt_SearchText'))
    )
    input.send_keys(keyword)

    # 定位“搜索”按钮节点并单击
    wait.until(EC.presence_of_element_located(
        (By.CLASS_NAME, 'search-btn'))).click()
    time.sleep(3)  # 休眠3s

    # 定位每页文章篇数列表节点并单击
    wait.until(EC.presence_of_element_located(
        (By.CSS_SELECTOR, '[class="icon icon-sort"]'))).click()

    # 定位每页文章篇数“50”节点并单击
    wait.until(EC.presence_of_all_elements_located(
        (By.CSS_SELECTOR, '#id_grid_display_num ul li')))[2].click()
    time.sleep(3)  # 休眠3s

    parse_page()

# 定义解析网页函数
def parse_page():
    wait.until(
        EC.presence_of_all_elements_located(
            (By.CSS_SELECTOR, '.result-table-list tbody tr')
        )
    )
    html = browser.page_source  # 获取HTML源代码
    soup = BeautifulSoup(html, 'lxml')  # 创建BeautifulSoup对象，并设置使用lxml解析器
    items = soup.select('.result-table-list tbody tr')  # 使用CSS选择器查找tr节点

    # 遍历列表，提取文章信息
    for i in range(0, len(items)):
        item = items[i]
        detail = item.select('td')  # 使用CSS选择器查找td节点
        paper = {
            'index': detail[0].text.strip(),
            'title': detail[1].text.strip(),
            'author': detail[2].text.strip(),
            'resource': detail[3].text.strip(),
            'time': detail[4].text.strip(),
            'database': detail[5].text.strip()
        }
        print(paper)  # 输出文章信息
        data_storage(paper)  # 调用data_storage函数

def data_storage(paper):
    try:
        collection.insert_one(paper)
    except Exception:
        print('failedly storage!', paper)

# 定义翻页函数
def next_page():
    try:
        # 判断id值为“Page_next_top”的节点是否可见
        page_next = wait.until(
            EC.visibility_of_element_located(
                (By.CSS_SELECTOR, '#Page_next_top')
            )
        )
    except TimeoutException:
        return False  # 返回False
    else:
        page_next.click()  # 单击节点
        return True  # 返回True

if __name__ == '__main__':
    keyword = 'Python'
    searcher(keyword)
    while True:
        flag = next_page()
        time.sleep(5)
        if flag:
            parse_page()
            continue
        else:
            break
    browser.close()