import requests 
from lxml import etree 

# 定义headers字典
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0'
}

# 定义url字符串
chapter_url = 'https://www.bi09.cc/book/126417/1.html'

r = requests.get(chapter_url, headers=headers)  # 发送请求，并将返回结果赋值给r

# 获取返回内容编码类型
# print(r.text)
print(r.apparent_encoding)
code_type = r.apparent_encoding

# 判断编码类型是否是GB2312，如果是，改变编码类型为GBK
if code_type == 'GB2312':
    code_type = 'GBK'
r.encoding = code_type  # 重定义返回内容编码类型
html = etree.HTML(r.text)  # 创建HTML对象html

# 选择h1节点并提取文本，将返回的列表第一项赋值给title
title = html.xpath('//h1/text()')
print(title)  # 输出第一章节的标题

# 选择id属性值为"content"的div节点并提取文本
# contents = html.xpath('//div[@id="content"]/text()')
contents = html.xpath('//div[@id="chaptercontent"]/text()')
len(contents) - 3  # 为了减去末尾不是文章的部分
for i in contents[0:len(contents) - 3]:  # 遍历列表
    # 移除字符串头尾的空格，并赋值给content
    content = i.strip()
    print(content)  # 输出第一章节的正文