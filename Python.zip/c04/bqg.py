import requests
import urllib.parse
from lxml import etree

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

novel_base_url = 'https://www.bqg128.com'
novel_url = urllib.parse.urljoin(novel_base_url, '/book/97040')

header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36'
}

r = requests.get(novel_url, headers=header)
html = etree.HTML(r.text)
div = html.xpath(
    '//div[@class="listmain"]')
a = div[0].xpath('dl/dd/a')
hrefs = [a[i].xpath('@href')[0] for i in range(len(a))]
# print(hrefs)
for href in hrefs:
    if href.startswith('/book/'):
        url = urllib.parse.urljoin(novel_base_url, href)

        # 设置 Selenium WebDriver
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')
        driver = webdriver.Chrome(options=options)

        driver.get(url)

        # 等页面加载
        time.sleep(1)

        redirected_url = driver.current_url
        page_source = driver.page_source

        driver.quit()

        print("重定向后的 URL:", redirected_url)
        print("页面内容:", page_source)  # 打印部分内容


        page_source = etree.HTML(page_source)
        # 标题
        chapter_title = page_source.xpath('//h1[@class="wap_none"]/text()')[0].strip()
        print("标题:", chapter_title)

        content = page_source.xpath('//div[@id="chaptercontent"]//text()')
        content = "".join(content).strip()
        print("内容:", content)

        file_name = f"{chapter_title}.txt"
        with open(file_name, "w", encoding="utf-8") as file:
            file.write(f"{chapter_title}\n\n")
            file.write(content)

        print(f"已保存为 {file_name}")
